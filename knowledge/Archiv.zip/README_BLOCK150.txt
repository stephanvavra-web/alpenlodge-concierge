ALPENLODGE – BLOCK(150) Paket (Begriffe 141–150)

Run:
  python3 scan_overpass_50km.py alpenlodge_50km_scan_config_block150.json

Output:
  alpenlodge_verified_50km_osm_dump.json

Validieren:
  python3 validate_50km_json.py alpenlodge_verified_50km_osm_dump.json

ALPENLODGE – BLOCK(100) Paket (Begriffe 91–100)

Run:
  python3 scan_overpass_50km.py alpenlodge_50km_scan_config_block100.json

Output:
  alpenlodge_verified_50km_osm_dump.json

Validieren:
  python3 validate_50km_json.py alpenlodge_verified_50km_osm_dump.json

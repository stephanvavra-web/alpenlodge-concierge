ALPENLODGE – BLOCK(170) Paket (Begriffe 161–170)

Run:
  python3 scan_overpass_50km.py alpenlodge_50km_scan_config_block170.json

Output:
  alpenlodge_verified_50km_osm_dump.json

Validieren:
  python3 validate_50km_json.py alpenlodge_verified_50km_osm_dump.json
